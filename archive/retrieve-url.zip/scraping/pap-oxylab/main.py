from utils import *


def handler(event, context):
    scrape_ad("https://www.pap.fr/annonces/maison-la-celle-saint-cloud-r448201718")
